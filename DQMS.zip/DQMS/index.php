<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DQMS</title>
    <?php include('./client/commonFiles.php');?>
</head>

<body>
    <?php
    session_start();
    error_reporting(0);
    include('./client/header.php');


    if(isset($_GET['signup']) && !$_SESSION['user']['uname']){
    include('./client/signup.php');

    }
    else if(isset($_GET['login']) && !$_SESSION['user']['uname']){
    include('./client/login.php');
    }
    else if($_GET['ask']){
        include('./client/ask.php');


    }
    else if($_GET['question-id']){
        $qid=$_GET['question-id'];
        include('./client/question-details.php');


    }
    else if($_GET['category-id']){
       $cid=$_GET['category-id'];
        include('./client/question.php');
    }
    else if($_GET['u-id']){
        $uid=$_GET['u-id'];
         include('./client/question.php');
     }
     else if($_GET['latest']){
        include('./client/question.php');
     }
     else if($_GET['search']){
        $s=$_GET['search'];
        include('./client/question.php');
     }
    else{
        include('./client/question.php');
    }

    ?>

</body>

</html>