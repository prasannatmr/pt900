<?php
 $host='localhost';
 $uname='root';
 $pass='';
 $db='dqms';
$conn=new mysqli($host,$uname,$pass,$db);
if($conn->connect_error){
    die("connect error: " . $conn->connect_error);
}
// else{
//     echo "Connected successfully";
// }


?>