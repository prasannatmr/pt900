<?php

session_start();
include ('../common/db.php');
if(isset($_POST['signin'])){
   $uname=$_POST['uname'];
   $email=$_POST['email'];
   $pass=$_POST['pass'];
   $address=$_POST['address'];

   $user=$conn->prepare("INSERT INTO `signup`(`id`, `uname`, `email`, `pass`, `address`)
   values(null, '$uname', '$email', '$pass', '$address');

   ");
$result=$user->execute();
$user->insert_id;
if($result){
    $_SESSION["user"] = ["uname"=>$uname,"email"=>$email,"user_id"=>$user->insert_id];
    header("Location: /DQMS");
}
    else{
        echo "Registration Failed";
    }
}else if(isset($_POST['login']) ){

    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $loginQuery="select*from signup where email='$email'and pass='$pass'";
    $result=$conn->query($loginQuery);
    $username="";
$user_id=0;
    if($result->num_rows==1){
        foreach($result as $row){
           $username=$row['uname'];
           $user_id=$row['id'];
        }
        $_SESSION["user"]=['uname'=>$username,'email'=>$email,"user_id"=>$user_id];
        header('Location:/DQMS');
    }else{
echo "user not found";
    }
}

else if(isset($_GET['logout'])){
    session_unset();
    header("Location: /DQMS");
}
else if(isset($_POST['submit'])){
    $title=$_POST['title'];
    $description=$_POST['description'];
    $category=$_POST['category'];
    $user_id=$_SESSION['user']['user_id'];

    $user1=$conn->prepare("INSERT INTO `question`(`id`, `title`, `description`, `category_id`, `user_id`)
    values(null, '$title', '$description', '$category', '$user_id');

    ");
 $result1=$user1->execute();
 $user1->insert_id;
 if($result1){
    // print_r($result1);
    //  $_SESSION["user"] = ["uname"=>$uname,"email"=>$email,"user_id"=>$user1->insert_id];
     header("Location: /DQMS");
 }
     else{
         echo "Submit Question Successfully";
     }
 }else if(isset($_POST['ans'])){
    $answer=$_POST['ans'];
    $question_id=$_POST['question_id'];
    $user_id=$_SESSION['user']['user_id'];

    $question=$conn->prepare("INSERT INTO `answer`(`id`, `answer`, `question_id`, `user_id`)
    values(null, '$answer', '$question_id', '$user_id');

    ");
 $result1=$question->execute();

 if($result1){
    // print_r($result1);
    //  $_SESSION["user"] = ["uname"=>$uname,"email"=>$email,"user_id"=>$user1->insert_id];
     header("Location: /DQMS?question-id=$question_id");
 }
     else{
         echo "Answer is not submitted";
     }
 }

?>