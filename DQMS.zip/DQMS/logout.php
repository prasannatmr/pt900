<?php
// $_SESSION['signup']=['uname'=>$uname,'email'=>$email];
session_unset();
session_destroy();
header("Location: index.php")


?>