<div class="container">
    <h1 class="text-center mt-3">Ask A Question</h1>
    <form action="./server/requests.php" method="post">
        <div class="col-6 offset-sm-3 mb-3">
            <label for="title" class="col-sm-2 col-form-label">Title</label>
            <input type="text" class="form-control" id="title" placeholder="Enter Your title" name="title">
        </div>
        <div class="col-6 offset-sm-3 mb-3">
            <label for="Desc" class="col-sm-2 col-form-label">Description</label>
            <textarea class="form-control" name="description" id="Desc" rows="3"
                placeholder="Type Description Here........"></textarea>
        </div>
        <div class="col-6 offset-sm-3 mb-3">
            <label for="category" class="col-sm-2 col-form-label">Category</label>
            <?php include('./client/category.php');?>
        </div>
        <button type="submit" class="btn btn-warning offset-sm-3" name="submit">Submit</button>
    </form>
</div>