<select class="form-control" name="category" id="category">
    <option value="">Select one</option>

    <?php
include('./common/db.php');
$query1="select * from category";
$result=$conn->query($query1);
foreach($result as $row){
    $id=$row['id'];
    $name=ucfirst($row['name']);
    echo "<option value=$id>$name</option>";
}
?>
</select>