<div class="container">

    <div class="row">

        <div class="col-8">
            <h1 class="text-center mt-3">Question</h1>
            <?php include('./common/db.php');
    $query="select * from question where id=$qid";
$result=$conn->query($query);
$row=$result->fetch_assoc();
$cid=$row['category_id'];
    echo '<div class="card mt-5 ">
  <div class="card-header">
    Question :
  </div>
  <div class="card-body">
    <h5 class="card-title">'.$row['title'].'</h5>

    <p class="card-text">'.$row['description'].'</p>' ?>
            <?php include('./client/answer.php');?>
            <form action="./server/requests.php" method="post">
                <input type="hidden" name="question_id" value='<?php echo $qid ?>'>
                <textarea name="ans" placeholder="type your answer....." class="form-control"></textarea>
                <button class="btn btn-warning text-dark mt-3">Write your answer</button>
            </form>
        </div>
    </div>
</div>
<div class="col-4">

    <?php
    $categoryQuery="select name from category where id=$cid ";
    $cResult=$conn->query($categoryQuery);
  $categoryRow=$cResult->fetch_assoc();
  // print_r($categoryRow);
  echo " <h1 class='text-center mt-3'>".ucfirst($categoryRow['name'])."</h1>";
    $query="select * from question where category_id=$cid and id!=$qid";
    // print_r($query);
    $result = $conn->query($query);
    foreach($result as $row){
      $id=$row['id'];
      $title=$row['title'];
      echo "<div class='question-list '><h4 class='p-3 mt-5'><a href='?question-id=$id'>$title</a></h4></div>";
    }
    ?>
</div>
</div>
</div>