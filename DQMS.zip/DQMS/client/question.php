<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="text-center mt-3">Top-Questions</h1>

            <?php include('./common/db.php');
            if(isset($_GET['category-id'])){
                $query="select * from question where category_id = $cid";
            }
            else if(isset($_GET['u-id'])){
                $query="select * from question where user_id=$uid";
                // print_r($query);
            }
            else if(isset($_GET['latest'])){
                $query="select * from question order by id desc";
                // print_r($query);
            }
            else if(isset($_GET['search'])){
                $s=$_GET['search'];
                 $query="select * from question where `title` LIKE '%$s%'";

            }
            else{
                $query="select * from question";
            }

$result=$conn->query($query);
foreach($result as $row){
    $title=ucfirst($row['title']);
    $id=$row['id'];


echo '<div class="card  mt-5  ms-5 container question-list">
<div class="card-body">
    <blockquote class="blockquote mb-0 ">
        <p><a href="?question-id='.$id.'"> Q.) '.$title.'</a></p>

    </blockquote>
</div>
</div>';

}
?>
        </div>
        <div class="col-4">
            <?php include('./client/category-list.php')?>
        </div>
    </div>
</div>