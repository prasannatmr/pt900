<div>
    <h1 class="text-center mt-3">Category</h1>
    <?php include('./common/db.php');
$query="select * from category";
$result=$conn->query($query);
foreach($result as $row){
    $name=ucfirst($row['name']);
    $id=$row['id'];


echo '<div class="card  mt-5  ms-5 container question-list">
<div class="card-body">
    <blockquote class="blockquote mb-0 ">
        <p class=" text-center"><a href="?category-id='.$id.'" > '.$name.'</a></p>

    </blockquote>
</div>
</div>';

}
?>
</div>