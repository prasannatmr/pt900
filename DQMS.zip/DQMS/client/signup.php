<div class="container">
    <h1 class="text-center mt-3">Sign-Up</h1>
    <form action="./server/requests.php" method="post">
        <div class="col-6 offset-sm-3 mb-3">
            <label for="username" class="col-sm-2 col-form-label">User Name : </label>
            <input type="text" class="form-control " id="username" placeholder="Enter Your Name" name="uname">
        </div>
        <div class="col-6 offset-sm-3 mb-3">
            <label for="email" class="col-sm-2 col-form-label">Email</label>
            <input type="email" class="form-control" id="email" placeholder="Enter Your Email" name="email">
        </div>
        <div class="col-6 offset-sm-3 mb-3">
            <label for="password" class="col-sm-2 col-form-label">Password</label>
            <input type="password" class="form-control" id="password" placeholder="Enter Your Password" name="pass">
        </div>
        <div class="col-6 offset-sm-3 mb-3">
            <label for="address" class="col-sm-2 col-form-label">Address</label>
            <input type="text" class="form-control" id="address" placeholder="Enter Your Address" name="address">
        </div>

        <button type="submit" class="btn btn-warning offset-sm-3" name="signin">Sign in</button>
    </form>
</div>