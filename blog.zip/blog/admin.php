 <?php
  session_start();
 $cookieConsent=isset($_COOKIE['cookieConsent']) ? $_COOKIE['cookieConsent'] : '';
if($cookieConsent==="accepted"){
header('Cache-Control: no-cache');
//    echo "cookies are accepted";

}
else if($cookieConsent==="declined"){
    $_SESSION['cookienotset']="Please Accept Our Cookies";



}
else{
    $_SESSION['cookienotset']="You did not choose our cookies";


}?>
 <?php include('header.php');

 ?>
 <!-- Cookie Consent Banner -->
 <div id="cookieConsentBanner"
     style="position: fixed; bottom: 0; width: 100%; background: #333; color: white; text-align: center; padding: 15px; display: none;">
     <p>We use cookies to improve your experience. By using our website, you agree to our use of cookies.
         <a href="#" style="color: #f1c40f;">Learn more</a>
     </p>
     <button id="acceptCookies"
         style="background-color: #4CAF50; color: white; border: none; padding: 10px 20px; cursor: pointer;">Accept
         Cookies</button>
     <button id="declineCookies"
         style="background-color: #f44336; color: white; border: none; padding: 10px 20px; cursor: pointer;">Decline</button>
     <?php
     if(isset($_SESSION['cookienotset'])){
        $cookieError=$_SESSION['cookienotset'];
        echo "<p style='color:red;'>".$cookieError."</p>";
        session_unset();
     }
     ?>

 </div>
 <script>
if (document.cookie.indexOf('cookieConsent') == -1) {
    document.getElementById('cookieConsentBanner').style.display = 'block';
} else {
    document.getElementById('cookieConsentBanner').style.display = 'none';

}
document.getElementById('acceptCookies').onclick = function() {
    document.cookie = "cookieConsent=accepted;  max-age=" + (60 * 60 * 24 * 365);
    document.getElementById('cookieConsentBanner').style.display = 'none';

}

document.getElementById('declineCookies').onclick = function() {
    document.cookie = "cookieConsent=declined;  max-age=" + (60 * 60 * 24 * 365);
    document.getElementById('cookieConsentBanner').style.display = 'none';


}
 </script>
 <?php include('footer.php');
 ?>