-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2025 at 08:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `blog_title` varchar(255) NOT NULL,
  `blog_detail` longtext NOT NULL,
  `blog_img` varchar(255) NOT NULL,
  `category` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `publish_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_title`, `blog_detail`, `blog_img`, `category`, `author_id`, `publish_date`) VALUES
(13, 'first', '<p>this is our new posttrdyh</p>\r\n', 'img-1.jpg', 149, 0, '2024-12-28 17:01:59'),
(14, ' Building Scalable Web Applications: Key Concepts and Tools', '<p>Discuss the core principles of scalability in web applications, including load balancing, caching, and cloud infrastructure. Share tools and services that help in scaling apps efficiently.</p>\r\n', '20-205971_phone-in-hand-png-mobile-frame-png-with.png', 151, 1, '2024-12-29 15:50:38'),
(15, ' Introduction to Full-Stack Development: From Frontend to Backend', '<p>Guide beginners through the journey of becoming a full-stack developer. Discuss key technologies for frontend (React, Angular, Vue) and backend (Node.js, Django, Ruby on Rails) development.</p>\r\n', 'img-1.jpg', 152, 1, '2024-12-29 15:58:07'),
(16, ' The Power of API Integration: Connecting Your Apps to the World', '<p>Explain the importance of APIs in modern software. Cover REST vs. GraphQL, tips for secure API consumption, and how to build a simple API in your chosen framework.</p>\r\n', 'img-1.jpg', 153, 1, '2024-12-29 15:59:51'),
(17, ' Mastering Version Control with Git and GitHub: A Complete Guide', '<p>A deep dive into using Git and GitHub effectively for version control. Topics can include branching strategies, commit messages, and collaboration workflows.</p>\r\n', 'img-1.jpg', 154, 1, '2024-12-29 16:00:18'),
(18, 'Security Best Practices for Web Developers', '<p>Discuss the top security threats for web applications, such as XSS, CSRF, and SQL injection. Provide practical steps to safeguard against these risks.</p>\r\n', 'img-1.jpg', 155, 1, '2024-12-29 16:00:46'),
(19, 'Building and Deploying Serverless Applications with AWS Lambda', '<p>Introduce the concept of serverless architecture. Walk through how to create and deploy a simple serverless app using AWS Lambda and other AWS services.</p>\r\n', 'img-1.jpg', 156, 1, '2024-12-29 16:01:16'),
(20, ' Testing Strategies for Web Development: Unit, Integration, and E2E Testing', '<p>Explain the importance of testing in software development. Provide an overview of testing types and introduce popular testing frameworks (e.g., Jest, Mocha, Cypress).</p>\r\n', 'img-1.jpg', 157, 1, '2024-12-29 16:01:54'),
(21, 'Progressive Web Apps (PWAs): Making Your Web App Mobile-Ready', '<p>Discuss how to turn a standard web application into a Progressive Web App. Cover caching strategies, offline functionality, and performance optimizations.</p>\r\n', 'img-1.jpg', 158, 1, '2024-12-29 16:02:24'),
(22, 'The Role of CI/CD in Modern Software Development', '<p>Introduce continuous integration and continuous deployment practices. Share how tools like Jenkins, CircleCI, or GitHub Actions help automate your development pipeline</p>\r\n', 'img-1.jpg', 159, 1, '2024-12-29 16:02:49'),
(23, ' Leveraging Cloud Computing for DevOps and Infrastructure as Code', '<p>Explain the DevOps culture and how Infrastructure as Code (IaC) tools like Terraform or AWS CloudFormation streamline infrastructure management.</p>\r\n', 'img-1.jpg', 160, 1, '2024-12-29 16:03:19'),
(24, 'The Future of Remote Work: Trends to Watch in 2025', '<p>Explore how remote work is evolving, from hybrid models to virtual offices, and the tools that are reshaping how we work.</p>\r\n', 'img-1.jpg', 151, 16, '2025-01-01 14:14:49');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
(151, 'Web Applications'),
(152, 'Full-Stack Development'),
(153, 'API Integration'),
(154, 'Version Control'),
(155, 'Security'),
(156, 'Serverless Applications'),
(157, 'Testing Strategies'),
(158, 'Progressive Web Apps '),
(159, 'Modern Software Development'),
(160, 'Cloud Computing ');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `role` int(1) NOT NULL,
  `user_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `user_email`, `role`, `user_password`) VALUES
(16, 'prasanna', 'prasannatmr8900@gmail.com', 1, '$2y$10$1yohZ0/w.sCjevr9DI4zju8ihcds7Ewtbmj..D7.RWiW0Gwx1Wn66'),
(17, 'mona', 'monatomar7289@gmail.com', 0, '$2y$10$m8wnt22oOzMe00Rurnu8beNtuDhNtbc.Yep1hw3PBgwWkubc5U6ei');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
