<?php include('header.php');
 $blogid=$_GET['id'];
if(empty($blogid)){
    header('location:index.php');
    exit;
}
if(isset($_SESSION['user'])) {
    $uid=$_SESSION['user']['uid'];
}


// echo $blogid;
$sql="select * from blog left join category on blog.category=category.cat_id left join user on blog.author_id=user.user_id where blog_id=' $blogid' order by blog.publish_date desc";
$result1=$conn->query($sql);
$data=$result1->fetch_assoc();

?>

<div class="card shadow ">
    <div class="card-header py-3 d-flex justify-content-between ">

        <div class="w-100">
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <h6 style="text-align:left">Tittle :</h6>
                    <input type="text" class="form-control" name="blog_title" placeholder="Tittle...."
                        value="<?= $data['blog_title']?>" required>
                </div>
                <div class="mb-3">
                    <h6 style="text-align:left">Description :</h6>
                    <textarea name="blog_detail" id="blog"><?= $data['blog_detail']?></textarea>
                </div>

                <div class="mb-3 w-100 d-flex">
                    <!-- <h6 style="text-align:left">Image :</h6> -->
                    <input type="file" class="form-control " name="blog_img">
                    <img src="upload/<?= $data['blog_img']?>" width="100px">
                    <!-- <h6 style="text-align:left">Image :</h6> -->
                    <select name="category" class="form-control offset-1 " required>

                        <?php

                        $query="select * from category";

                        $result=$conn->query($query);
                        if($result->num_rows>0){

                            foreach($result as $row){
                                $cat_name=ucfirst($row['cat_name']);
                                $id=ucfirst($row['cat_id']);

                            ?>

                        <option value="<?= $id?>" <?= ($data['category']==$id) ? "selected": "" ?>>
                            <?= $cat_name?>
                        </option>
                        <?php }  } ?>
                    </select>
                </div>
                <div class=" mb-3 d-flex justify-content-end">
                    <a href="index.php" class="btn btn-secondary me-2">Close</a>
                    <button type="submit" class="btn btn-primary" name="update_blog">Update
                        post</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include('footer.php');
if(isset($_POST['update_blog'])){
    $title=mysqli_real_escape_string($conn,$_POST['blog_title']);
    $blog_detail=mysqli_real_escape_string($conn,$_POST['blog_detail']);
    $author_id=$uid;
    $filename=$_FILES['blog_img']['name'];
    $tmp_name=$_FILES['blog_img']['tmp_name'];
    $size=$_FILES['blog_img']['size'];
    $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    $allow=['jpg','png','jpeg'];
    $destination="upload/".$filename;
    $category=mysqli_real_escape_string($conn,$_POST['category']);
    if(!empty($filename)){
    if(in_array($ext,$allow)){
        if($size<=2000000){
            $unlink="upload/".$data['blog_img'];
            unlink($unlink);
            move_uploaded_file($tmp_name,$destination);
            $query="update blog set blog_title='$title',blog_detail='$blog_detail',blog_img='$filename',category='$category',author_id='$author_id' where blog_id='$blogid' ";
            $result=$conn->query($query);
            if($result){
                $_SESSION['cat_message']=["Blog has been updated successfully",'success','Good job!'];
                header("Location:index.php");
            }
            else{
                $_SESSION['cat_message']=['Failed to update blog','error','Oops...'].$conn->error;
                header("Location:index.php");
            }
        }
    }
}
else{
    $query="update blog set blog_title='$title',blog_detail='$blog_detail',category='$category',author_id='$author_id' where blog_id='$blogid' ";
    $result=$conn->query($query);
    if($result){
        $_SESSION['cat_message']=["Blog has been updated successfully",'success','Good job!'];
        header("Location:index.php");

    }
    else{
        $_SESSION['cat_message']=['Failed to update blog','error','Oops...'].$conn->error;
        header("Location:index.php");
    }
}

}
?>