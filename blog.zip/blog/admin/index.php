<?php include('header.php');

if(isset($_SESSION['user'])){
    $uid=$_SESSION['user']['uid'];

}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h5 class="mb-2 text-gray-800">Blog Posts</h5>
    <!-- DataTales Example -->
    <div class="card shadow">
        <div class="card-header py-3 d-flex justify-content-between">
            <div>
                <a href="add_blog.php" class="btn btn-primary">
                    New Blog +
                </a>
            </div>
            <div>
                <form class="navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-white border-0 small" placeholder="Search for...">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button"> <i class="fa fa-search fa-sm"></i> </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" cellpadding="0">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Author</th>
                            <th>Date</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        $query="select * from blog  left join category on blog.category=category.cat_id
                        left join user on blog.author_id=user.user_id where user_id='$uid' order by blog.publish_date desc";
                        $result = $conn->query($query);
                        $count=0;

                        if($result->num_rows>0){
                            foreach($result as $row){

                                ?>
                        <tr>
                            <td>
                                <?= ++$count;?>
                            </td>
                            <td>
                                <p style="font-weight:bold;">
                                    <?= $row['blog_title']?></p>
                            </td>
                            <td>
                                <p>
                                    <?= $row['cat_name']?>
                                </p>
                            </td>
                            <td>
                                <a>
                                    <?=  $row['username']?>
                                </a>
                            </td>
                            <td>
                                <?= date('d-M-Y',strtotime($row['publish_date']))?>
                            </td>

                            <td>
                                <a href="update-blog.php?id=<?= $row['blog_id']?>" class="btn btn-success">
                                    Edit
                                </a>

                            </td>
                            <td>
                                <form action="../request-handler.php" method="post"
                                    onsubmit="return confirm('are you sure want to delete Post..?')">
                                    <input type="hidden" name="blog_id" value="<?php echo $row['blog_id']?>">
                                    <input type="hidden" name="blog_img" value="<?php echo $row['blog_img']?>">

                                    <input type="submit" class="btn btn-danger" value="Delete" name="deletPost">
                                </form>
                            </td>

                        </tr>



                        <?php }


                        }else{?>
                        <tr>
                            <td colspan="6">No record Found</td>
                        </tr>

                        <?php }

                        ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<?php include('footer.php')?>