<?php include('header.php');
if(empty($_SESSION['user']['role'])){
    header('location:index.php');
    exit;
}
?>
<?php

$query="select * from category";

$result=$conn->query($query);
if($result->num_rows>0){



    ?>
<div class="card shadow ">
    <div class="card-header py-3 d-flex justify-content-between ">

        <div class="w-100">
            <form action="../request-handler.php" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <h6 style="text-align:left">Tittle :</h6>
                    <input type="text" class="form-control" name="blog_title" placeholder="Tittle...." required>
                </div>
                <div class="mb-3">
                    <h6 style="text-align:left">Description :</h6>
                    <textarea name="blog_detail" id="blog"></textarea>
                </div>

                <div class="mb-3 w-50 d-flex">
                    <!-- <h6 style="text-align:left">Image :</h6> -->
                    <input type="file" class="form-control " name="blog_img" placeholder="Tittle....">
                    <!-- <h6 style="text-align:left">Image :</h6> -->
                    <select name="category" class="form-control offset-1 " required>
                        <option>Select Category...</option>
                        <?php  foreach($result as $row){
        $cat_name=ucfirst($row['cat_name']);
        $id=ucfirst($row['cat_id']);?>

                        <option value="<?= $id?>"> <?= $cat_name ?></option>
                        <?php }} ?>
                    </select>
                </div>
                <div class=" mb-3 d-flex justify-content-end">
                    <a href="index.php" class="btn btn-secondary me-2">Close</a>
                    <button type="submit" class="btn btn-primary" name="add_blog">Add
                        Blog</button>
                </div>

            </form>
        </div>
    </div>
</div>

<?php include('footer.php');?>