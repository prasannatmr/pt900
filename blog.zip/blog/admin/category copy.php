<?php
include('header.php')

?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h5 class="mb-2 text-gray-800">Categories</h5>
    <!-- DataTales Example -->
    <div class="card shadow">
        <div class="card-header py-3 d-flex justify-content-between">

            <form class="navbar-search" action="../request-handler.php" method="post">
                <div class="input-group">
                    <input type="text" class="form-control" id="recipient-name" name="category_name"
                        placeholder="add new category" required>
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-primary " name=" add_category">Add</button>
                    </div>
                </div>
            </form>



            <div>
                <form class="navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-white border-0 small" placeholder="Search for...">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button"> <i class="fa fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered " id=" dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Category Name</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query="select * from category";
                        $result = $conn->query($query);
                        $count=0;
                        if($result->num_rows){
                            foreach($result as $row){
                                $cat_name=ucfirst($row['cat_name']);
                                $id=ucfirst($row['cat_id']);


                                ?>
                        <tr>
                            <td>
                                <?= ++$count?>
                            </td>
                            <td><?= $cat_name;?></td>

                            <td>
                                <button class="btn btn-success" data-bs-toggle="modal"
                                    data-bs-target="#modal-<?= $id?>">
                                    Edit
                                </button>
                                <div class="modal fade" id="modal-<?=  $id ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5">Update
                                                    Category</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="../request-handler.php" method="post">
                                                    <div class="mb-3">
                                                        <h6 style="text-align:left">Category name:</h6>
                                                        <input type="text" class="form-control" name="cat_name"
                                                            value="<?= $cat_name ?>">
                                                        <input type="hidden" name="cat_id" value="<?=  $id ?>">
                                                    </div>
                                                    <div class="mb-3 d-flex justify-content-end">
                                                        <button type="button" class="btn btn-secondary me-2"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary"
                                                            name="update_cat">Update</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <td>
                                <form action="../request-handler.php" method="post"
                                    onsubmit="return confirm('are you sure want to delete category..?')">
                                    <input type="hidden" name="deletId" value="<?php echo $id?>">
                                    <input type="submit" class="btn btn-danger" value="Delete" name="delet">
                                </form>
                            </td>
                            </td>

                        </tr>

                        <?php

                          }

                        }

                        else {?>

                        <tr>
                            <td colspan="3">
                                <h5 class="text-danger">No record found....!</h5>
                            </td>
                        </tr>

                        <?php
                            }
                            ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<?php include('footer.php');

?>