<?php
include('header.php');
if(isset($_POST['add-user'])){
    $uname=$_POST['uname'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $co_pass=$_POST['co-password'];
    $role=$_POST['role'];
if(strlen($uname)< 4 || strlen($uname)> 100){
   $error ="Username should be between 4 and 8 characters long";
}
else if(strlen($pass)<4 || strlen($pass)> 8){
    $error="Password should be between 4 and 8 characters long";
    } else if($pass != $co_pass){
    $error="Password and Confirm Password not matched";
    }else{
        $query="select * from user where user_email='$email'";
        $result=$conn->query($query);
        $data=$result->num_rows;
        if($data){
            $error="email already in use";
    }else{
        $pass=password_hash($pass,PASSWORD_DEFAULT);
        $query="insert into user (`username`,`user_email`,`role`,`user_password`) values ('$uname','$email','$role','$pass')";
        $result=$conn->query($query);
        if($result){
            $success="User added successfully";
        } else{
            $error="Failed to add user";
        }
    }

    }
}
    ?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <?php if(!empty($error)){

echo "<p class='bg-danger p-3 text-light '>$error</p>";
            //    unset_session($_SESSION['cat_message']);
                }
                else if(!empty($success)){
                    echo "<p class='bg-success p-3 text-light '>$success</p>";
                }


                ?>
    <!-- Page Heading -->
    <h5 class="mb-2 text-gray-800">Categories</h5>
    <!-- DataTales Example -->
    <div class="card shadow">
        <div class="card-header py-3 d-flex justify-content-between">
            <button type="button" class="btn btn-primary " name=" add_user" data-bs-target="#register_modal"
                data-bs-toggle="modal">Register
                New User +
            </button>


            <div class="modal" tabindex="-1" id="register_modal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Register New User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <form method="post" action="">

                                <div class=" mb-3">
                                    <label for="recipient-name" class="col-form-label">Username:</label>
                                    <input type="text" class="form-control" id="recipient-name" name="uname"
                                        placeholder="Enter your username" value="<?= (!empty($error)) ? "$uname": ""?>"
                                        required>
                                </div>
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Email:</label>
                                    <input type="text" class="form-control" id="recipient-name"
                                        placeholder="Enter your email" name="email"
                                        value="<?= (!empty($error))?"$email":""?>">
                                </div>
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Password:</label>
                                    <input type="password" class="form-control" id="recipient-name"
                                        placeholder="Enter your password" name="password">
                                </div>
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Confrim Password:</label>
                                    <input type="password" class="form-control" id="recipient-name"
                                        placeholder="Enter your confirm password" name="co-password">
                                </div>
                                <div class="mb-3">
                                    <select name="role" class="form-control">
                                        <option value="1">Admin</option>
                                        <option value="0">Co-Admin</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-primary" name="add-user">Add New
                                        User</button>

                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <form class="navbar-search">
                    <div class="input-group">
                        <input type="text" class="form-control bg-white border-0 small" placeholder="Search for...">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button"> <i class="fa fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered " id=" dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php

    $query="select * from user";
    $result=$conn->query($query);
$count=0;

    if($result->num_rows>0){
        foreach($result as $data){




    ?>


                        <tr>

                            <td><?= ++$count;?></td>
                            <td><?= $data['username']?></td>
                            <td><?= $data['user_email']?></td>
                            <td>
                                <?php $role = $data['role'];
                             if($role==1){
                              echo "Admin";
                            }else{
                                 echo "Co-Admin";

                            }
                            ?>
                            </td>
                            <td>
                                <form action="../request-handler.php" method="post"
                                    onsubmit="return confirm('are you sure want to delete it.?')">
                                    <input type="hidden" name="delete" value="<?= $role;?>">
                                    <button type="submit" class="btn btn-danger" type="button" name="delete-user">
                                        Delete
                                    </button>
                                </form>

                            </td>

                        </tr>
                        <?php       }}

else{
    echo "<tr><td colspan='6'>No Record Found</td></tr>";

}

     ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<?php include('footer.php');

?>