<?php
$conn=mysqli_connect('localhost','root','','blog_web');
if($conn->error){
    die("Error connecting to $conn->error");
}
// else{
//    echo "connecting";
// }
?>