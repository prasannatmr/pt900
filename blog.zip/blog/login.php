<?php include('header.php');
session_start();
if(isset($_SESSION['user']['uid'])){
    header('location:admin/index.php');
    exit();
}?>
<div class="container">
    <div class="row mt-5 inner-div">
        <div class="col-6 ">
            <h1>Login</h1>
            <form action="request-handler.php" method="post">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                        name="email" placeholder="Enter your email"
                        value="<?= isset($_COOKIE['adminEmail'])? $_COOKIE['adminEmail'] : '' ?>" required>

                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" name="password"
                        placeholder="Enter your password" required>
                    <button type="button" class="btn btn-primary" id="show"><i class="bi bi-eye"></i> Show
                        Password</button>
                    <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const pass = document.getElementById('exampleInputPassword1');
                        const show = document.getElementById('show');
                        show.addEventListener('click', () => {
                            if (pass.type == 'password' && pass.value != '') {
                                pass.type = 'text';
                                show.innerHTML = '<i class="bi bi-eye-slash"></i>  Hide Password';
                            } else {

                                pass.type = 'password';
                                show.innerHTML = '<i class="bi bi-eye"></i>  Show Password';
                            }
                        })
                    });
                    </script>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" name='remember_me'>
                    <label class="form-check-label" for="exampleCheck1">Remember Me</label>
                </div>
                <button type="submit" class="btn btn-primary " name="login" value="login">Login</button>
                <button type="reset" class="btn btn-danger ">Cancel</button>
                <?php
                    if(isset($_SESSION['error'])){
                        $error=$_SESSION['error'];
                        echo "<p class='text-danger'>".$error."</p>";
                        session_unset();
                    }
                ?>
            </form>
        </div>
    </div>
</div>
<?php include('footer.php');?>