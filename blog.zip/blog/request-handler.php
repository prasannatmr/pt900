<?php
include('conn.php');
session_start();

if(isset($_POST['login'])){
$email =mysqli_real_escape_string( $conn,$_POST['email']);
$password =mysqli_real_escape_string( $conn,$_POST['password']);
$query="select * from user where user_email='$email'";
$result=$conn->query($query);
$uname='';

    if($result->num_rows>0){
        $data=$result->fetch_assoc();

        $uname=$data['username'];
        $uid=$data['user_id'];
        $role=$data['role'];

        $_SESSION['user']=['username'=>$uname,'email'=>$email,'uid'=>$uid, 'role'=>$role];
        $storedHash = $data['user_password'];
        if (password_verify($password, $storedHash) ) {
            // Password is correct
           header("Location:admin/index.php");
        }
        if (isset($_POST['remember_me'])) {
        setcookie('adminEmail', $email, time() + (60 * 60), "/", "", false, true);

        // setcookie('adminPassword', $_POST['password'], time() + (60 * 60), "/", "", false, true);
        }
        else{
            $_SESSION['error']="Incorrect username or Password".$conn->error;
            }

        }



}

 if(isset($_POST['add_category'])){
    $name=mysqli_real_escape_string($conn,$_POST['category_name']);
    $query="select * from category where cat_name='$name'";
    $result=$conn->query($query);
    if($result->num_rows >0){
       $_SESSION['cat_message']= ['Category already exists','error','Oops...'];
       header('location:admin/category.php');
       unset_session($_SESSION['cat_message']);
    }
    else{
        $query1="insert into category (cat_name) values ('$name')";
        $result1=$conn->query($query1);
        if($result1){
            $_SESSION['cat_message']= ['Category add successfully','success','Good job!'];
            header('location:admin/category.php');
            unset_session($_SESSION['cat_message']);
        }
else{
    $_SESSION['cat_message']=['Failed to add category','error','Oops...'].$conn->error;
    header('location:admin/category.php');
    unset_session($_SESSION['cat_message']);
}


    }
}
else if(isset($_GET['logout'])){
    session_unset();
    session_destroy();
header('location: login.php');
}
else if(isset($_POST['delet'])){
    $id=$_POST['deletId'];
    $dltQuery="delete from category where cat_id='$id'";
    $dltResult=$conn->query($dltQuery);
if($dltResult){

    $_SESSION['cat_message']= ["Category has been deleted",'success','Deleted!'];
    header('location:admin/category.php');
    unset_session($_SESSION['cat_message']);
}
else{
    $_SESSION['cat_message']=['Failed to delete category','error','Oops...'].$conn->error;
    header('location:admin/category.php');
    unset_session($_SESSION['cat_message']);
}

 }

 else if(isset($_POST['update_cat'])){
    $id=$_POST['cat_id'];
    $cat_name=$_POST['cat_name'];
    $r="select * from category where cat_name='$cat_name'";
$result=$conn->query($r);
if($result->num_rows>0){
   $_SESSION['cat_message']=['Already Exist !! category cannot been updated','error','Oops...'];
   header('location:admin/category.php');
   unset_session($_SESSION['cat_message']);
}
else{
    $query1="update category set cat_name='$cat_name' where cat_id='$id'";
    $result1=$conn->query($query1);
    if($result1){
        $_SESSION['cat_message']=["Category has been updated",'success','Updated!'];
        header('location:admin/category.php');
        unset_session($_SESSION['cat_message']);
    }
    else{
 $_SESSION['cat_message']=['something went wrong','error','Oops...'].$conn->error;
header('location:admin/category.php');
unset_session($_SESSION['cat_message']);
    }
}
}
else if(isset($_POST['add_blog'])){
    $title=mysqli_real_escape_string($conn,$_POST['blog_title']);
    $blog_detail=mysqli_real_escape_string($conn,$_POST['blog_detail']);
    $author_id=$_SESSION['user']['uid'];
    $filename=$_FILES['blog_img']['name'];
    $tmp_name=$_FILES['blog_img']['tmp_name'];
    $size=$_FILES['blog_img']['size'];
    $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    $allow=['jpg','png','jpeg'];
    $destination="upload/".$filename;
    $category=mysqli_real_escape_string($conn,$_POST['category']);
    if(in_array($ext,$allow)){
        if($size<=2000000){
            move_uploaded_file($tmp_name,$destination);
            $query="insert into `blog`(`blog_title`,`blog_detail`,`blog_img`,`category`,`author_id`) values ('$title','$blog_detail','$filename','$category','$author_id') ";
            $result=$conn->query($query);
            if($result){
                $_SESSION['cat_message']=["Blog has been added successfully",'success','Good job!'];
                header('location:admin/add_blog.php');

            }
            else{
                $_SESSION['cat_message']=['Failed to add blog','error','Oops...'].$conn->error;
                header('location:admin/add_blog.php');

            }

        }

    }
    else{
        echo "Not uploaded image: " . $conn->error;
    }

}else if(isset($_POST['deletPost'])){
    $id=$_POST['blog_id'];
    $img="upload/".$_POST['blog_img'];
    $dltPost="delete from blog where blog_id='$id'";
    $result=$conn->query($dltPost);
    if($result){
        unlink($img);
        $_SESSION['cat_message']=["Blog has been deleted successfully",'success','Deleted!'];
        header('location:admin/index.php');
        unset_session($_SESSION['cat_message']);
    }
    else{
        $_SESSION['cat_message']=['Failed to delete blog','error','Oops...'].$conn->error;
        header('location:admin/index.php');
        unset_session($_SESSION['cat_message']);
    }

}
else if(isset($_POST['delete-user'])){
    // print_r($_POST);
    $role=$_POST['delete'];
    $query="delete from user where role='$role'";
    $result=$conn->query($query);
    if($result==1){
        $_SESSION['cat_message']=["User has been deleted successfully",'success','Deleted!'];
        header('location:admin/user.php');
        // unset_session($_SESSION['cat_message']);
    }
    else{
        $_SESSION['cat_message']=['Failed to delete user','error','Oops...'].$conn->error;
        header('location:admin/user.php');
        // unset_session($_SESSION['cat_message']);
    }
}


?>